package com.packetsoftware.sime.controller;

public class Pessoa {
    private String idpessoa;
    private String nomepessoa;
    private String cpfpessoa;

    public String getIdpessoa() {
        return idpessoa;
    }

    public void setIdpessoa(String idpessoa) {
        this.idpessoa = idpessoa;
    }

    public String getNomepessoa() {
        return nomepessoa;
    }

    public void setNomepessoa(String nomepessoa) {
        this.nomepessoa = nomepessoa;
    }

    public String getCpfpessoa() {
        return cpfpessoa;
    }

    public void setCpfpessoa(String cpfpessoa) {
        this.cpfpessoa = cpfpessoa;
    }
}
