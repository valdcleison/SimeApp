package com.packetsoftware.sime.controller;

public class Usuario {

    private int idusuario;
    private String usuario;
    private String emailpessoa;
    private String niveladmin;
    private String statususuario;
    private String nomepessoa;
    private String cpfpessoa;



    public int getIdusuario() {
        return idusuario;
    }

    public void setIdusuario(int idusuario) {
        this.idusuario = idusuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getEmailpessoa() {
        return emailpessoa;
    }

    public void setEmailpessoa(String emailpessoa) {
        this.emailpessoa = emailpessoa;
    }

    public String getNiveladmin() {
        return niveladmin;
    }

    public void setNiveladmin(String niveladmin) {
        this.niveladmin = niveladmin;
    }

    public String getStatususuario() {
        return statususuario;
    }

    public void setStatususuario(String statususuario) {
        this.statususuario = statususuario;
    }

    public String getNomepessoa() {
        return nomepessoa;
    }

    public void setNomepessoa(String nomepessoa) {
        this.nomepessoa = nomepessoa;
    }

    public String getCpfpessoa() {
        return cpfpessoa;
    }

    public void setCpfpessoa(String cpfpessoa) {
        this.cpfpessoa = cpfpessoa;
    }
}
