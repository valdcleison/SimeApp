package com.packetsoftware.sime.controller;

public class Aluno {
    private String idaluno;
    private Pessoa pessoa;

    public String getIdaluno() {
        return idaluno;
    }

    public void setIdaluno(String idaluno) {
        this.idaluno = idaluno;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }


}
