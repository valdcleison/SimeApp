package com.packetsoftware.sime.controller;

import java.util.List;

public class SimeFrequenciaAluno {
    private String status;
    private String menssage;
    private Frequenciaaluno frequenciaaluno;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMenssage() {
        return menssage;
    }

    public void setMenssage(String menssage) {
        this.menssage = menssage;
    }

    public Frequenciaaluno getFrequenciaaluno() {
        return frequenciaaluno;
    }

    public void setFrequenciaaluno(Frequenciaaluno frequenciaaluno) {
        this.frequenciaaluno = frequenciaaluno;
    }
}
